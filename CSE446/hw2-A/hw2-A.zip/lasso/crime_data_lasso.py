if __name__ == "__main__":
    from ISTA import train  # type: ignore
else:
    from .ISTA import train

import matplotlib.pyplot as plt
import numpy as np

from utils import load_dataset, problem


@problem.tag("hw2-A", start_line=3)
def main():
    # df_train and df_test are pandas dataframes.
    # Make sure you split them into observations and targets
    df_train, df_test = load_dataset("crime")

    y_train = df_train["ViolentCrimesPerPop"].values
    X_train = df_train.drop("ViolentCrimesPerPop", axis=1).values
    y_test = df_test["ViolentCrimesPerPop"].values
    X_test = df_test.drop("ViolentCrimesPerPop", axis=1).values

    n, d = X_train.shape
    w = np.zeros(d)

    # Lambda
    curr_lambda = np.max(2 * np.abs(X_train.T @ (y_train - np.mean(y_train))))
    lambdas = []

    # Number of non-zero features
    nonzeros = []

    # Features to plot
    coefficients = {feature: [] for feature in ["agePct12t29", "pctWSocSec", "pctUrban", "agePct65up", "householdsize"]}
    feature_indices = [df_train.columns.get_loc(feature) for feature in coefficients.keys()]

    # Errors
    train_errors = []
    test_errors = []

    while curr_lambda >= 0.01:
        w, b = train(X_train, y_train, curr_lambda, start_weight=w, start_bias=0)
        
        lambdas.append(curr_lambda)
        curr_lambda *= 0.5

        curr_nonzeros = np.count_nonzero(w)
        nonzeros.append(curr_nonzeros)

        for feature, index in zip(coefficients.keys(), feature_indices):
            coefficients[feature].append(w[index])

        train_errors.append(np.mean((y_train - X_train @ w + b) ** 2))
        test_errors.append(np.mean((y_test - X_test @ w + b) ** 2))
    
    # Plot the number of non-zero features vs lambda
    plt.plot(lambdas, nonzeros, "o-")
    plt.xscale('log')
    plt.xlabel('λ')
    plt.ylabel('Number of non-zero features')
    plt.title('Feature Selection Path')
    plt.show()

    # Plot the coefficients of the selected features
    for feature in coefficients.keys():
        plt.plot(lambdas, coefficients[feature], label=feature)
    
    plt.xscale('log')
    plt.xlabel('λ (log scale)')
    plt.ylabel('Coefficient Value')
    plt.title('Regularization Paths for Selected Features')
    plt.legend()
    plt.grid(True)
    plt.show()

     # Plot the squared errors
    plt.plot(lambdas, train_errors, label='Training Error', marker='o')
    plt.plot(lambdas, test_errors, label='Test Error', marker='o')
    
    plt.xscale('log')
    plt.xlabel('λ (log scale)')
    plt.ylabel('Mean Squared Error')
    plt.title('Training and Test Squared Errors')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Train the model with lambda = 30
    w, b = train(X_train, y_train, 30, start_weight=w, start_bias=0)
    nonzeros_30 = np.count_nonzero(w)

    coefficients_30 = {feature: 0 for feature in df_train.columns if feature != "ViolentCrimesPerPop"}
    for feature, index in zip(coefficients_30.keys(), range(len(coefficients_30))):
        coefficients_30[feature] = w[index]

    max_feature = max(coefficients_30, key=coefficients_30.get)
    min_feature = min(coefficients_30, key=coefficients_30.get)
    print(f"Feature with the largest coefficient: {max_feature} ({coefficients_30[max_feature]})")
    print(f"Feature with the most negative coefficient: {min_feature} ({coefficients_30[min_feature]})")

    train_error_30 = np.mean((y_train - X_train @ w) ** 2)
    test_error_30 = np.mean((y_test - X_test @ w) ** 2)

    print(f"Number of non-zero features: {nonzeros_30}")
    print(f"Training error: {train_error_30}")
    print(f"Test error: {test_error_30}")

        


if __name__ == "__main__":
    main()
